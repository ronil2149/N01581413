package org.example.n01581413_ghoghari_test3_ims.controller;

import org.example.n01581413_ghoghari_test3_ims.Services.ProductServices;
import org.example.n01581413_ghoghari_test3_ims.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private ProductServices productService;

    @GetMapping
    public String getAllproducts(Model model) {
        model.addAttribute("productsList", productService.getAllproducts());
        return "product-list";
    }

    @GetMapping("/add")
    public String showAddProductForm(Model model) {
        model.addAttribute("product", new Product());
        return "product-add";
    }

    @PostMapping("/add")
    public String addEmployee(@ModelAttribute Product product) {
        ProductServices.addProduct(product);
        return "redirect:/products";
    }

    @GetMapping("/{id}")
    public String getProductDetails(@PathVariable int id, Model model) {
        Product product = ProductServices.getProductById(id);
        model.addAttribute("product", product);
        return "product-details";
    }

    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable int id, Model model) {
        Product product = ProductServices.getProductById(id);
        model.addAttribute("product", product);
        return "product-edit";
    }

    @PostMapping("/update/{id}")
    public String updateEmployee(@PathVariable int id, @ModelAttribute Product employee) {
        ProductServices.updateProduct(id, employee);
        return "redirect:/products";
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable int id) {
        ProductServices.deleteProduct(id);
        return "redirect:/products";
    }
}


