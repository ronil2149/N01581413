package org.example.n01581413_ghoghari_test3_ims.Services;

import org.example.n01581413_ghoghari_test3_ims.model.Product;
import org.example.n01581413_ghoghari_test3_ims.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServices {
    private static ProductRepository ProductRepository;

    public ProductServices(org.example.n01581413_ghoghari_test3_ims.repository.ProductRepository productRepository) {
        ProductRepository = productRepository;
    }

    public void ProductService(ProductRepository productRepository) {
        this.ProductRepository = productRepository;
    }

    public List<Product> getAllproducts() {
        return ProductRepository.findAll();
    }

    public static Product addProduct(Product product) {
        return ProductRepository.save(product);
    }

    // Method to update an employee
    public static Product updateProduct(int id, Product updatedProduct) {
        Optional<Product> existingProduct = ProductRepository.findById(id);

        if (existingProduct.isPresent()) {
            updatedProduct.setId(id);
            return ProductRepository.save(updatedProduct);
        }
        return null;
    }

    public static void deleteProduct(int id) {
        if (ProductRepository.existsById(id)) {
            ProductRepository.deleteById(id);
        }
    }

    public static Product getProductById(int id) {
        return ProductRepository.findById(id).orElse(null);
    }
}



