package org.example.n01581413_ghoghari_test3_ims.repository;


import org.example.n01581413_ghoghari_test3_ims.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
}






